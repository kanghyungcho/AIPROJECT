# Settings =====================================================================
# Load Modules
import os

import pandas as pd
import numpy as np

from imblearn.under_sampling import RandomUnderSampler
from imblearn.under_sampling import TomekLinks
from imblearn.under_sampling import OneSidedSelection

from imblearn.over_sampling import RandomOverSampler
from imblearn.over_sampling import SMOTE
from imblearn.over_sampling import ADASYN

from imblearn.metrics import geometric_mean_score

from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split

from statsmodels.discrete.discrete_model import Logit
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier

import matplotlib.pyplot as plt
import seaborn as sns

# Set Working Directory
os.chdir("D:/Dropbox/Education/2017_SK_Planet/loan_practice")

# Read Data
DF = pd.read_csv("./loan_data.csv")

# Data Exploration =============================================================
# Data Structure
print(DF.shape)
print(DF.dtypes)
print(DF.describe(include = 'all'))

# Correlation Heatmap
sns.set(context="paper", font="monospace")
corr = DF.corr()
plt.figure(figsize=(12, 10))
sns.heatmap(corr, vmin=-1.0, vmax=1.0, square=True,
            cmap=sns.diverging_palette(240, 10, as_cmap=True))

# Pairplot
select_columns = ['TOT_LOAN', 'LOAN_BNK', 'LOAN_CPT',
                  'LATE_RATE', 'CALL_TIME', 'TEL_COST_MON', 'TARGET']
sns.pairplot(DF[select_columns], hue='TARGET', size=2, plot_kws={"s": 6})

# Bar Chart
sns.countplot(x='TARGET', data=DF)

# Box Plot
sns.boxplot(y='CRDT_CNT', x='TARGET', data=DF, showmeans=True)
sns.boxplot(y='AGE', x='TARGET', data=DF, showmeans=True)

# Data Preprocessing ===========================================================
# Split into X and y
y = DF['TARGET']
X = DF.drop('TARGET', 1)

# 1-of-C coding (dummy variable)
X = pd.get_dummies(X)
X = X.drop(['SEX_M', 'PAY_METHOD_A', 'JOB_A'], axis=1)
columns = X.columns.tolist()
print(columns)

# (Stratified) Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    test_size=0.2,
                                                    random_state=111,
                                                    stratify=y)

X_val, X_test, y_val, y_test = train_test_split(X_test, y_test,
                                                test_size=0.5,
                                                random_state=111,
                                                stratify=y_test)

# min-max scaling
scaler = MinMaxScaler()
scaler.fit(X_train)
X_train = scaler.transform(X_train)
X_val = scaler.transform(X_val)
X_test = scaler.transform(X_test)

# Create Datasets --------------------------------------------------------------
# Original Dataset
X_simple, y_simple = X_train.copy(), y_train.copy()

del X_train
del y_train

## UnderSampling
# Random Undersampling
rus = RandomUnderSampler()
X_rus, y_rus= rus.fit_sample(X_simple, y_simple)
print('RUS Shape: {} x {}'.format(*X_rus.shape))

# Tomek Links
tl = TomekLinks()
X_tl, y_tl = tl.fit_sample(X_simple, y_simple)
print('Tomek Shape: {} x {}'.format(*X_tl.shape))

# One-side selection
oss = OneSidedSelection()
X_oss, y_oss = oss.fit_sample(X_simple, y_simple)
print('OSS Shape: {} x {}'.format(*X_oss.shape))

## OverSampling
# Random Oversampling
ros = RandomOverSampler()
X_ros, y_ros = ros.fit_sample(X_simple, y_simple)
print('ROS Shape: {} x {}'.format(*X_ros.shape))


# SMOTE ('regular')
sm = SMOTE(k_neighbors=5, kind='regular')
X_sm, y_sm = sm.fit_sample(X_simple, y_simple)
print('SMOTE Shape: {} x {}'.format(*X_sm.shape))

# Borderline-SMOTE
blsm = SMOTE(k_neighbors=5, m_neighbors=2, kind='borderline1')
X_blsm, y_blsm = blsm.fit_sample(X_simple, y_simple)
print('Borderline Shape: {} x {}'.format(*X_blsm.shape))

# ADASYN
adas = ADASYN(n_neighbors=3)
X_adas, y_adas= adas.fit_sample(X_simple, y_simple)
print('ADASYN Shape: {} x {}'.format(*X_adas.shape))

## Save Datasets
dataset_names = ['Simple',
                 'Random Under', 'Tomek', 'One Side',
                 'Random Over', 'SMOTE', 'Borderline', 'ADASYN']
datasets = [(X_simple, y_simple),
            (X_rus, y_rus), (X_tl, y_tl), (X_oss, y_oss),
            (X_ros, y_ros), (X_sm, y_sm), (X_blsm, y_blsm), (X_adas, y_adas)]

# Model Construction ===========================================================
result_fin = pd.DataFrame(np.zeros((len(dataset_names), 6)),
                          index = dataset_names,
                          columns = ["n_obs",
                                     "DT", "LR", "RF", "kNN",
                                     "best_k"])


# Model Evaluation -------------------------------------------------------------
for ds_name, ds in zip(dataset_names, datasets):
    
    X_train, y_train = ds
    
    result_fin.loc[ds_name, 'n_obs'] = X_train.shape[0]
    
    # Decision Tree
    dt = DecisionTreeClassifier()
    dt.fit(X_train, y_train)
    y_pred = dt.predict(X_test)
    score = geometric_mean_score(y_test, y_pred)
    score = round(score, 3)
    result_fin.loc[ds_name, 'DT'] = score
    
    # Logistic Regression
    logit = Logit(endog=y_train, exog=X_train)
    result = logit.fit(maxiter=1000, disp=0)
    y_pred = logit.predict(params=result.params, exog=X_test).round()
    score = geometric_mean_score(y_test, y_pred)
    score = round(score, 3)
    result_fin.loc[ds_name, 'LR'] = score
    
    # Random Forest
    rf = RandomForestClassifier(n_estimators=200)
    rf.fit(X_train, y_train)
    y_pred = rf.predict(X_test)
    score = geometric_mean_score(y_test, y_pred)
    score = round(score, 3)
    result_fin.loc[ds_name, 'RF'] = score
    
    # k-NN Classifier ----------------------------------------------------------
    neighbors = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]

    # Validation to choose best k
    scoreList = []
    for k in neighbors:
        knn = KNeighborsClassifier(n_neighbors=k)
        knn.fit(X_train, y_train)
        y_pred = knn.predict(X_val)
        k_score = geometric_mean_score(y_pred, y_val)
        scoreList.append(k_score)
    best_index = scoreList.index(max(scoreList))
    best_k = neighbors[best_index]
    result_fin.loc[ds_name, 'best_k'] = best_k
    
    # Fit and Predict (test data)
    knn = KNeighborsClassifier(n_neighbors=best_k)
    knn.fit(X_train, y_train)
    y_pred = knn.predict(X_test)
    score = geometric_mean_score(y_test, y_pred)
    score = round(score, 3)
    result_fin.loc[ds_name, 'kNN'] = score
    
    print('{} Dataset Finishied'.format(ds_name))



# Check effect of each variable ================================================
# Logistic Regression (Coefficients)
logit = Logit(endog=y_sm, exog=X_sm)
result = logit.fit(maxiter=1000, disp=0)
result.summary()

# Get p-values and Coefficients
pval = result.pvalues
coef = result.params

# Get variables with pvalue < 0.05
imp_index = np.where(pval < 0.05)
columns = np.array(columns)

imp_pval = pval[imp_index]
imp_coef = coef[imp_index]
imp_vars = columns[imp_index]

# Plot
plt.figure(figsize=(8,8))
plt.barh(range(len(imp_vars)), imp_coef, color='r')
plt.yticks(range(len(imp_vars)), imp_vars)
plt.show()

# Random Forest (Feature Importances)
rf = RandomForestClassifier(n_estimators=200)
rf.fit(X_rus, y_rus)

importances = rf.feature_importances_
std = np.std([tree.feature_importances_ for tree in rf.estimators_],
             axis=0)
indices = np.argsort(importances)[::-1]

plt.figure(figsize=(8, 8))
plt.title("Feature Importances")
plt.barh(range(X.shape[1]), importances[indices],
         color='r', xerr=std[indices])
plt.yticks(range(X.shape[1]), columns[indices])
plt.show()

